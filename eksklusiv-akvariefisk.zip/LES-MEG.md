# Eksklusiv Akvariefisk – slik får du nettsiden på lufta

Nettsiden er ferdig bygget. Den hostes gratis på **Netlify**, filene ligger på **GitHub**, og fiskene redigerer du i adminpanelet på `dinside.no/admin`.

Det tar ca. 20–30 minutter første gang. Du gjør det bare én gang.

---

## 1. Last opp filene til GitHub
1. Lag en gratis konto på https://github.com
2. Trykk **New repository**, kall det `eksklusiv-akvariefisk`, og trykk **Create repository**.
3. Trykk **uploading an existing file** og dra inn *alt innholdet* i mappen (index.html, css, js, data, admin, bilder osv.). Trykk **Commit changes**.
4. Åpne `admin/config.yml` på GitHub (blyant-ikonet), bytt `BRUKERNAVN` med GitHub-brukernavnet ditt og lagre.

## 2. Publiser på Netlify
1. Lag en gratis konto på https://www.netlify.com og logg inn med GitHub.
2. **Add new project → Import an existing project → GitHub**, og velg `eksklusiv-akvariefisk`.
3. La byggefeltene stå tomme, og trykk **Deploy**. Etter et minutt er siden ute på en adresse som `noe-tilfeldig.netlify.app`. (Du kan endre navnet under *Project configuration*.)

## 3. Få forespørsler på e-post
1. I Netlify: gå til **Forms** og slå på skjemagjenkjenning (*Enable form detection*).
2. Gå til **Deploys** og trykk **Trigger deploy** én gang, så Netlify finner skjemaet.
3. Under **Forms → Form notifications → Add notification → Email notification**: velg skjemaet `foresporsel` og skriv `isakseen99@gmail.com`.
4. Send en test fra nettsiden. Første e-post kan havne i søppelpost; marker den som «ikke søppel».

Alle forespørsler ligger også under **Forms** i Netlify.

## 4. Slå på innlogging til adminpanelet
1. På GitHub: profilbilde → **Settings → Developer settings → OAuth Apps → New OAuth App**
   - *Homepage URL*: adressen til siden din (f.eks. `https://eksklusiv-akvariefisk.netlify.app`)
   - *Authorization callback URL*: `https://api.netlify.com/auth/done`
2. Lagre, kopier **Client ID** og lag en **Client secret**.
3. I Netlify: **Project configuration → Access & security → OAuth → Install provider → GitHub**, og lim inn begge.
4. Gå til `din-adresse/admin` og logg inn med GitHub.

## 5. Bruke adminpanelet
- **Fisker for salg**: legg til, endre eller fjern fisker. Last opp bilde, sett pris og status (På lager / Få igjen / Kommer snart / Utsolgt). Huk av «Vis på nettsiden» for å skjule en fisk uten å slette den.
- **Kategorier**: lag egne kategorier. Filterknappene på forsiden lages automatisk.
- **Tekster og kontaktinfo**: om oss, Mattilsynet-teksten, telefon, adresse og org.nr.
- Trykk **Publish**. Siden er oppdatert etter ca. 1 minutt.

Vil flere redigere? Legg dem til som *Collaborator* på GitHub-repoet (Settings → Collaborators).

**Bilder:** Bruk liggende bilder (4:3), helst under 500 kB. Fisker uten bilde får en tegnet fisk som plassholder.

## 6. Eget domene (når dere er klare)
1. Kjøp domenet hos en norsk registrar, f.eks. Domeneshop eller One.com (et .no-domene krever norsk org.nr.).
2. Netlify: **Domain management → Add a domain**, og følg instruksjonene for å peke DNS-en dit. HTTPS settes opp automatisk.
3. Oppdater *Homepage URL* i GitHub OAuth-appen til det nye domenet.

---

**Før dere går live:** Eksempelfiskene og tekstene er bare plassholdere. Bytt dem ut med deres egne i adminpanelet, og legg inn org.nr. og telefon.
